from flask import Flask, request, render_template, jsonify
import csv, datetime

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/edit')
def edit():
    f = open("mysite/iot_1.conf", "r")
    gpio_1 = f.read()
    f.close()
    f = open("mysite/iot_2.conf", "r")
    gpio_2 = f.read()
    f.close()
    return render_template('edit.html',gpio_1=gpio_1,gpio_2=gpio_2)

@app.route('/view')
def view():
    with open('mysite/iot_1_sensor.log', mode='r') as file:
        reader = csv.reader(file)
        data = [row for row in reader]
    return render_template('view.html',data=data)

@app.route('/iot_1_conf')
def iot_1_conf():
    gpio=request.args.get("gpio")
    f = open("mysite/iot_1.conf", "w")
    f.write(gpio)
    f.close()
    return render_template('iot_1_conf.html',gpio=gpio)

@app.route('/iot_2_conf')
def iot_2_conf():
    gpio=request.args.get("gpio")
    f = open("mysite/iot_2.conf", "w")
    f.write(gpio)
    f.close()
    return render_template('iot_2_conf.html',gpio=gpio)

@app.route('/sense')
def sense():
    data = request.args.get("data").split(",")
    f = open("mysite/iot_1.conf", "r")
    gpio_1 = f.read()
    f.close()
    #get tempeature value from correct gpio
    temp=data[int(gpio_1)]
    #update sensor data
    f = open("mysite/iot_1_sensor.data", "w")
    f.write(temp)
    f.close()
    #write sensor data to log with timestamp
    timestamp=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    f = open("mysite/iot_1_sensor.log", "a")
    f.write(f"{timestamp},{temp}\n")
    f.close()
    #print final status
    return f'HTTP data received =  {data} <br><br> IoT Node-1 Sensor Data Collected at GPIO-{gpio_1} = {temp} <br><br> Data written to sensor log: {timestamp},{temp} '

@app.route('/act')
def act():
    f = open("mysite/iot_1_sensor.data", "r")
    temp = f.read()
    f.close()
    return temp